def count_symbols(string: str) -> int:
    return len(string)
